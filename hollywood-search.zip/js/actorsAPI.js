var buildTable = (jsonData, elementId) => {
	actorsJsonObj = JSON.parse(jsonData);
	let actorsTable = "<table border='1'>";
	actorsTable += "<tr><th>Available Actors to Search</th></tr>"
	for (let x in actorsJsonObj.Items) {
		actorsTable += "<tr><td>" + actorsJsonObj.Items[x].name + "</td></tr>";
		}
		actorsTable += "</table>";
	document.getElementById(elementId).innerHTML = actorsTable;
}

var buildCrossRefTable_backup = (jsonData, elementId) => {
    crossRefJsonObj = JSON.parse(jsonData);
    let titlesTable = "<table border='1'>";
    titlesTable += "<tr><th>Shared Titles</th></tr>"
    for (let x in crossRefJsonObj) {
        let unique_title_id = crossRefJsonObj[x];
        let titleData =  callGetTitleAPI(unique_title_id);
        console.log("title data: " + titleData);
        let title = titleData.title;
        let release_yr = titleData.release_year;
        titlesTable += "<tr><td>" + title + ' (' + release_yr + ')' + "</td></tr>";
        }
        titlesTable += "</table>";
    document.getElementById(elementId).innerHTML = titlesTable;
}

var buildCrossRefTable = (dataSet, elementId) => {
    let titlesTable = "<table border='1'>";
    titlesTable += "<tr><th>Shared Titles</th></tr>"
    for (let x in dataSet) {
        console.log("row: " + dataSet[x]);
        titlesTable += "<tr><td>" + dataSet[x] + "</td></tr>";
        }
        titlesTable += "</table>";
    document.getElementById(elementId).innerHTML = titlesTable;
}

// define the callAPI function that takes a first name and last name as parameters
var callActorsAPI = (elementId) => {
    // instantiate an API constant
    var API_ENDPOINT = "https://vflli6z93m.execute-api.us-east-1.amazonaws.com/dev";

    // instantiate a headers object
    var myHeaders = new Headers();

    // add content type header to object
    myHeaders.append("Content-Type", "application/json");
    
    // using built in JSON utility package turn object to string and store in a variable
    //var raw = JSON.stringify({"firstName":firstName,"lastName":lastName});
    
    // create a JSON object with parameters for API call and store in a variable
    var requestOptions = {
        method: 'GET',
        headers: myHeaders,
        mode: 'cors',
        body: null,
        redirect: 'follow'
    };
    
    // make API call with parameters and use promises to get response
    fetch(API_ENDPOINT, requestOptions)
    .then(response => response.text())
    .then(result => buildTable(JSON.parse(result).body, elementId))
    .catch(error => console.log('error', error));
}

// define the callAPI function that takes a first name and last name as parameters
async function callActorsCrossRefAPI (elementId, firstActor, secondActor) {
    // instantiate an API constant
    var API_ENDPOINT = "https://qeiizsc5ra.execute-api.us-east-1.amazonaws.com/dev/";

    // instantiate a headers object
    var myHeaders = new Headers();

    // add content type header to object
    myHeaders.append("Content-Type", "application/json");
    
    // using built in JSON utility package turn object to string and store in a variable
    var raw = JSON.stringify({"firstActor":firstActor,"secondActor":secondActor});
    
    // create a JSON object with parameters for API call and store in a variable
    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        //mode: 'cors',
        body: raw,
        redirect: 'follow'
    };
    
    // make API call with parameters and use promises to get response
    fetch(API_ENDPOINT, requestOptions)
    .then(response => response.text())
    .then(result => JSON.parse(result).body)
    .then(parsedResult => {
        console.log('callActorsCrossRefAPI.parsedResult: ' + parsedResult);
        return buildTitleData(parsedResult);
    })
    .then(finalSet => buildCrossRefTable(finalSet, elementId))
    .catch(error => console.log('error', error));
}

async function buildTitleData(titleIds) {
    let titleList = JSON.parse(titleIds);
    console.log('buildTitleData.titleIds: ' + titleIds);
    console.log('buildTitleData.titleList: ' + titleList);
    let titleDataArr = [];

    await callGetTitleAPI(titleIds, "title, release_year")
    .then(response => JSON.parse(response))
    .then(json => {
        console.log('buildTitleData.json: ' + JSON.stringify(json));
        //console.log('buildTitleData.json.body: ' + json.body);
        json.forEach((elem) => {
            console.log('buildTitleData.elem: ' + JSON.stringify(elem));
            titleDataArr.push(elem.title + ' (' + elem.release_year + ')');
        });
    });

    console.log('buildTitleData.titleDataArr: ' + titleDataArr);

    return titleDataArr;
}

async function callGetTitleAPI(title_ids, columnsToRead) {
    let jsonBodyToReturn = {};

    // instantiate an API constant
    var API_ENDPOINT = "https://a2lw2rch3e.execute-api.us-east-1.amazonaws.com/dev";

    let titleDataObj = {};

    // instantiate a headers object
    var myHeaders = new Headers();

    // add content type header to object
    myHeaders.append("Content-Type", "application/json");
    
    // using built in JSON utility package turn object to string and store in a variable
    var raw = JSON.stringify({"title_ids":title_ids, "cols":columnsToRead});
    console.log('callGetTitleAPI.raw: ' + raw);
    
    // create a JSON object with parameters for API call and store in a variable
    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        //mode: 'cors',
        body: raw,
        redirect: 'follow'
    };
    
    // make API call with parameters and use promises to get response
    jsonBodyToReturn = await fetch(API_ENDPOINT, requestOptions)
    .then(response => response.text())
    .then(result => {
        console.log('callGetTitleAPI.result: ' + result);
        return JSON.parse(result).body;
    })
    .catch(error => console.log('error', error));

    return jsonBodyToReturn;
}